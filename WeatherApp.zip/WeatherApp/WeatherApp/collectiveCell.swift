//
//  collectiveCell.swift
//  WeatherApp
//
//  Created by Mladena on 12/17/18.
//  Copyright © 2018 Mladena. All rights reserved.
//

import UIKit

class collectiveCell: UICollectionViewCell {
    
    
    @IBOutlet weak var timeColl: UILabel!
    
    @IBOutlet weak var iconColl: UIImageView!
    
    @IBOutlet weak var weatherColl: UILabel!
    
}
