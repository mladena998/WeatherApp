//
//  Model.swift
//  WeatherApp
//
//  Created by Mladena on 12/17/18.
//  Copyright © 2018 Mladena. All rights reserved.
//

import Foundation
import UIKit
import CoreLocation



struct dataD:Codable{
    var time:Int
    var summary:String
    var icon:String
    var sunriseTime:Int
    var sunsetTime:Int
    var humidity:Double
    var visibility:Double
    var temperatureMin:Double
    var temperatureMax:Double

}


struct Daily:Codable {
    var summary:String
    var icon:String
    var data:[dataD]
}



struct dataH:Codable {
   var time:Int
   var summary:String
   var icon:String
   var temperature:Double

}
struct  Hourly:Codable {
    var summary:String
    var data:[dataH]
}
struct Currently:Codable {
    var time:Int
    var summary:String
    var icon:String
    var temperature:Double

}
struct Weather:Codable {
   var latitude:Double
   var longitude:Double
   var timezone:String
   var offset:Int
   var currently:Currently
   var hourly:Hourly
    var daily:Daily
}

var weather:Weather?
var weatherArray:[Weather] = []

func getWeather(location: CLLocationCoordinate2D,completion:([Weather]?)->()){
let urlString = "https://api.darksky.net/forecast/52726817ef719851b64f0395caccfc17/\(location.latitude),\(location.longitude)?units=si"

    
    
let url = URL(string: urlString)
let jsonDecoder = JSONDecoder()
let data = try? Data(contentsOf: url!)

 weather = try? jsonDecoder.decode(Weather.self, from: data!)
    
    weatherArray.append(weather!)
completion(weatherArray)
    print("WeatherArray count: \(weatherArray.count)")
print(weather!)
}






//Priprema modela za table i collective View


var weekArrayT = [String]()
var timeArray = [String]()
var sunriseArray = [String]()
var sunsetArray = [String]()


func removeFirst() {
    if weatherArray.count > 0 && weatherArray.count < 2 {
        
        weatherArray.removeFirst()
        print(weatherArray.count)
        print(weatherArray)
        
      //  weather = nil
        print(weather!)
        deleteData()
    }
   
    
}





func getTime() {
    //collectiveView dva dana
    for i in weather!.hourly.data {
        let time1 = i.time
        let date = Date(timeIntervalSince1970: Double(time1))
        let timeFormater = DateFormatter()
        timeFormater.dateFormat = "HH:mm"
        let time = timeFormater.string(from:date )
        
        timeArray.append(time)
        
    }
   // timeArray = []
    //tableView dani u nedelji-prva celija
    for i in weather!.daily.data{
        let dateString = i.time
        let date = Date(timeIntervalSince1970: Double(dateString))
        let dateFormater = DateFormatter()
        dateFormater.dateFormat = "EEEE"
        let date1 = dateFormater.string(from: date)
        weekArrayT.append(date1)
       // print(weekArrayT)
        
        
    }
    
    for i in weather!.daily.data{
        let sunrise = i.sunriseTime
        let dateR = Date(timeIntervalSince1970: Double(sunrise))
        let timeFormaterRise = DateFormatter()
        timeFormaterRise.dateFormat = "HH:mm"
        let sunriseTime = timeFormaterRise.string(from: dateR)
        sunriseArray.append(sunriseTime)
      //  print("SUNRISE\(sunriseTime)")
        
        let sunset = i.sunsetTime
        let dateS = Date(timeIntervalSince1970: Double(sunset))
        let timeFormaterDown = DateFormatter()
        timeFormaterDown.dateFormat = "HH:mm"
        let sunsetTime = timeFormaterDown.string(from: dateS)
        sunsetArray.append(sunsetTime)
      //  print("SUNSET\(sunriseTime)")
        
    }
}

var tempArray = [Int]()
var tempMaxArray = [Int]()
var tempMinArray = [Int]()
var currentTemp = Double()
var tempMax = Double()
var tempMin = Double()
func getTemp(){
    //collectiveView vreme po satima
    for i in weather!.hourly.data{
        let temperature1 = i.temperature
        let temperature = Int(temperature1)
        
       // print(temperature)
        tempArray.append(temperature)
       // print(tempArray)
    }
    //tableView maximalna i minimalna temp
    for i in weather!.daily.data{
        let tempMax1 = i.temperatureMax
        let tempMin1 = i.temperatureMin
        tempMaxArray.append(Int(tempMax1))
        tempMinArray.append(Int(tempMin1))
      tempMax = tempMax1
      tempMin = tempMin1
        
    }
    
 let weatherC = weather?.currently.temperature
    currentTemp = weatherC!
    
    
    
}

var imageArrayT = [UIImage]()
var iconArray = [UIImage]()
var currentWeatherIcon1 = UIImage()
func getIcon(){
    //collectiveView ikonica po satima
    for i in weather!.hourly.data{
        let icon = i.icon
        let image = UIImage(named: icon)
        iconArray.append(image!)
       // print(iconArray)
    }
    //tableView ikonica po danima-prva celija
    for i in weather!.daily.data {
        let icon = i.icon
        let image = UIImage(named: icon)
        imageArrayT.append(image!)
        currentWeatherIcon1 = UIImage(named: icon)!
      //  print(imageArrayT)
    
}
}



var summaryArray = [String]()
var humidityArray = [Double]()
var visibilityArray = [Double]()
var timezone = String()
var summaryCurrent = String()
func getDescription(){
 
    for i in weather!.daily.data{
        let summary = i.summary
        summaryCurrent = summary
        print(summaryCurrent)
    }

    
    
    
}

func deleteData(){
    
     weekArrayT.removeAll()
     timeArray.removeAll()
     sunriseArray.removeAll()
     sunsetArray.removeAll()
     tempArray.removeAll()
     tempMaxArray.removeAll()
     tempMinArray.removeAll()
     imageArrayT.removeAll()
     iconArray.removeAll()
     summaryArray.removeAll()
     humidityArray.removeAll()
     visibilityArray.removeAll()
//     currentTemp = 0.0
//     tempMax = 0.0
//     tempMin = 0.0
//     summaryCurrent = ""
      

}


