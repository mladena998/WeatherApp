//
//  ViewController.swift
//  WeatherApp
//
//  Created by Mladena on 12/16/18.
//  Copyright © 2018 Mladena. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate,UITableViewDataSource,UITableViewDelegate,UISearchBarDelegate {
   
    let backgroundImage = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        searchBar.delegate = self
        collectiveView.delegate = self
        collectiveView.dataSource = self
        tableView.delegate = self
        tableView.dataSource = self
        
      
       updateLocation(location: "Belgrade")
        
        
       
    }
    

   
    override  func viewWillAppear(_ animated: Bool){
        self.collectiveView.reloadData()
        self.tableView.reloadData()
        
    }
     var  forecastData = [Weather]()

    @IBOutlet weak var miMaxImage: UIImageView!
    
    
    @IBOutlet weak var collectiveView: UICollectionView!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var currentWeather: UILabel!
    
    @IBOutlet weak var cityName: UILabel!
    
    @IBOutlet weak var maxTemp: UILabel!
    
    @IBOutlet weak var minTemp: UILabel!
    
    @IBOutlet weak var currentWeatherIcon: UIImageView!
  
    @IBOutlet weak var summary: UITextView!
    
    
    
    func AllData() {
        
                getTime()
                getTemp()
                getIcon()
                getDescription()
                backgroung()
        print("ALL DATA")
    }
    
 
   var brojac = 0
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder() //sklanja tastaturu kada korisnik klikne enter
        
        if searchBar.text != "" {
            brojac += 1
            print(brojac)
        }
        
        
      
        
        if let locationString = searchBar.text, !locationString.isEmpty && brojac == 1  {
            updateLocation(location: locationString)
            AllData()
            print("radi nekako")
            
        } else if brojac > 1  {
            
           
            print("vise od 1 \(brojac)")
        }
        

    }
    
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        removeFirst()
        print("removed")
        deleteData()
        
        if searchText.isEmpty {
            
//            tempMax = 0.0
//            tempMin = 0.0
//            summaryCurrent = ""
            brojac = 0
            deleteData()
            
            print("DELETED")
            DispatchQueue.main.async {
                self.currentWeather.reloadInputViews()
                self.maxTemp.reloadInputViews()
                self.minTemp.reloadInputViews()
                self.currentWeatherIcon.reloadInputViews()
                self.summary.reloadInputViews()
            }

            
        }
    }
   // var  forecastData = [Weather]()
    func updateLocation(location:String){
        CLGeocoder().geocodeAddressString(location) { (placemarks:[CLPlacemark]?, error:Error?) in
            
            if error == nil {
                if let location = placemarks?.first?.location {
                    getWeather(location: location.coordinate, completion: { (results:[Weather]?) in
                        
                        if let weatherData = results {
                            self.forecastData = weatherData
                            DispatchQueue.main.async {
                                self.collectiveView.reloadData()
                               self.tableView.reloadData()
                            }
                        
                        }
                    })
                }
            }


        }
        print("UPDATE LOCATION")
    }
   
    func backgroung(){
      currentWeather.text = "\(Int(currentTemp))°"
      cityName.text = searchBar.text?.uppercased()
        maxTemp.text = "\(Int(tempMax))°^"
        minTemp.text = "\(Int(tempMin))°"
        currentWeatherIcon.image = currentWeatherIcon1
        
        summary.text = summaryCurrent
    }
    
    
    
    
    //COLLECTIVE VIEW
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return timeArray.count
       
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collCell", for: indexPath) as! collectiveCell
        
      cell.timeColl.text = "\(timeArray[indexPath.item])"
        cell.iconColl.image = iconArray[indexPath.item]
        cell.weatherColl.text = "\(tempArray[indexPath.item])°"
        
        return cell
    }
    
    
    
 // TABLE VIEW
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weekArrayT.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
            let cell = tableView.dequeueReusableCell(withIdentifier: "weekTableCell", for: indexPath) as! weekTableCell
        
        
            cell.weekDayTab.text = weekArrayT[indexPath.row]
            cell.iconTab.image = imageArrayT[indexPath.row]
            cell.tempMax.text = "\(tempMaxArray[indexPath.row])°"
            cell.tempMin.text = "\(tempMinArray[indexPath.row])°"
        
            return cell
        


    
    }
    
    
    
}

