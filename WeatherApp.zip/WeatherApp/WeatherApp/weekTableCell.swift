//
//  weekTableCell.swift
//  WeatherApp
//
//  Created by Mladena on 12/17/18.
//  Copyright © 2018 Mladena. All rights reserved.
//

import UIKit

class weekTableCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    
    @IBOutlet weak var weekDayTab: UILabel!
    
    @IBOutlet weak var iconTab: UIImageView!
    
    @IBOutlet weak var tempMax: UILabel!
    @IBOutlet weak var tempMin: UILabel!
    
}
